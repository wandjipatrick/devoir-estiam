import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=545d8bd4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=545d8bd4"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=e789fa90"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import App from "/src/App.jsx";
import "/src/index.css?t=1716724778569";
import PlayerContextProvider from "/src/context/PlayerContext.jsx";
import { BrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=2388589d";
ReactDOM.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(BrowserRouter, { children: /* @__PURE__ */ jsxDEV(PlayerContextProvider, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "C:/Users/axelp/Downloads/113344_Spotify_Clone_React (1)/spotify/src/main.jsx",
    lineNumber: 11,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/axelp/Downloads/113344_Spotify_Clone_React (1)/spotify/src/main.jsx",
    lineNumber: 10,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/axelp/Downloads/113344_Spotify_Clone_React (1)/spotify/src/main.jsx",
    lineNumber: 9,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVk7QUFWWixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsU0FBUztBQUNoQixPQUFPO0FBQ1AsT0FBT0MsMkJBQTJCO0FBQ2xDLFNBQVNDLHFCQUFxQjtBQUU5QkgsU0FBU0ksV0FBV0MsU0FBU0MsZUFBZSxNQUFNLENBQUMsRUFBRUM7QUFBQUEsRUFDakQsdUJBQUMsaUJBQ0csaUNBQUMseUJBQ0csaUNBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQUksS0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSiIsIm5hbWVzIjpbIlJlYWN0IiwiUmVhY3RET00iLCJBcHAiLCJQbGF5ZXJDb250ZXh0UHJvdmlkZXIiLCJCcm93c2VyUm91dGVyIiwiY3JlYXRlUm9vdCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiXSwic291cmNlcyI6WyJtYWluLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAuanN4J1xuaW1wb3J0ICcuL2luZGV4LmNzcydcbmltcG9ydCBQbGF5ZXJDb250ZXh0UHJvdmlkZXIgZnJvbSAnLi9jb250ZXh0L1BsYXllckNvbnRleHQuanN4J1xuaW1wb3J0IHsgQnJvd3NlclJvdXRlciB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5cblJlYWN0RE9NLmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSkucmVuZGVyKFxuICAgIDxCcm93c2VyUm91dGVyPlxuICAgICAgICA8UGxheWVyQ29udGV4dFByb3ZpZGVyPlxuICAgICAgICAgICAgPEFwcCAvPlxuICAgICAgICA8L1BsYXllckNvbnRleHRQcm92aWRlcj5cbiAgICA8L0Jyb3dzZXJSb3V0ZXI+XG4gICAgXG4pXG4iXSwiZmlsZSI6IkM6L1VzZXJzL2F4ZWxwL0Rvd25sb2Fkcy8xMTMzNDRfU3BvdGlmeV9DbG9uZV9SZWFjdCAoMSkvc3BvdGlmeS9zcmMvbWFpbi5qc3gifQ==